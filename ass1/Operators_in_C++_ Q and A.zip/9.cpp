#include <iostream>
using namespace std;

int main() {
    cout<<"Failed amount : "<<(45)*20/100<< " students\n";
    cout<<"Failed boys : "<<((45)*20/100)-2<<endl;
    cout<<"Passed boys : "<<25-(((45)*20/100)-2);
    return 0;
}