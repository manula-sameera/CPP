#include <iostream>
using namespace std;

int main() {
    int width = 10;
    int length = 30;

    cout << "Area is :"<<(width * length);
    cout << "Parameter is :"<<width+width+length+length;
    return 0;
}