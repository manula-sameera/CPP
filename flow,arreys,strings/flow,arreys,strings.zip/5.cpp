#include <iostream>
#include <string.h>
#include <bits/stdc++.h>

using namespace std;

int main(){

    char str[100] ;
    int count = 1;
    cout<<"Enter a word : ";
    cin>>str;

    for(int i=0;str[i]!='\0';++i)
    {
        if(str[i]==' '){

        }else{
            count++;
        }
            
    }
    cout<<count;
}